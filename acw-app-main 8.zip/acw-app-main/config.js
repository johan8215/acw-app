/* ===========================================================
   ACW-App v3.8 Connected Lite
   Author: Johan A. Giraldo (JG) | Allston Car Wash
   =========================================================== */

const CONFIG = {
  BASE_URL: "https://script.google.com/macros/s/AKfycbyvKBaKxvAhoudDIXjUcmIef31ZTyvhujLRxzOoyQBneGpnpcnJkYpyzvXS3SCve4Z6/exec",
  APP_NAME: "Allston Car Wash",
  VERSION: "3.8.Connected.Lite",
};
